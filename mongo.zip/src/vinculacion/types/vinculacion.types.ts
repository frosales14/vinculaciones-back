export type VinculacionState =
  | 'En Planeacion'
  | 'En Curso'
  | 'Cancelada'
  | 'Finalizada';
